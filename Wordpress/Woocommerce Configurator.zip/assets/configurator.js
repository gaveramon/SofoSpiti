(() => {
  const root = document.querySelector('[data-configurator]');
  if (!root) return;

  const catalog = {
    hub:{name:'Aqara M3 Hub',price:129,qty:1},
    door:{name:'Door & Window Sensor P100',price:29,qty:2},
    leak:{name:'Water Leak Sensor',price:24,qty:1},
    climate:{name:'Aqara Climate Sensor W100',price:39,qty:1},
    energy:{name:'Aqara Smart Plug',price:25,qty:2},
    presence:{name:'Presence Sensor FP300',price:30,qty:1},
    alarm:{name:'Smoke / Alarm Sensor',price:35,qty:1},
    ac:{name:'AC Automation',price:0,qty:1},
    alerts:{name:'Notifications & Alerts',price:0,qty:1},
    setup:{name:'One-time Professional Setup',price:79,qty:1}
  };
  const state = {extra:{room:0,ac:0}, setup:false};

  const euro = n => new Intl.NumberFormat('nl-NL',{style:'currency',currency:'EUR',maximumFractionDigits:0}).format(n);

  function packageItems(){
    return Object.entries(catalog)
      .filter(([k]) => k !== 'setup' && catalog[k].qty > 0)
      .map(([k,p]) => ({key:k,...p}));
  }

  function render(){
    const items = packageItems();
    const extras = state.extra.room * 129 + state.extra.ac * 99;
    const base = items.reduce((s,p)=>s+p.price*p.qty,0);
    const total = base + extras + (state.setup ? catalog.setup.price : 0);
    const count = items.reduce((s,p)=>s+p.qty,0) + state.extra.room*5 + state.extra.ac*2 + (state.setup?1:0);

    root.querySelector('[data-total]').textContent = euro(total);
    root.querySelector('[data-cart-count]').textContent = count;
    root.querySelector('[data-cart-items]').innerHTML = items.map(p =>
      `<div class="sp-cart-item"><span>${p.name} <b>×${p.qty}</b></span><b>${p.price ? euro(p.price*p.qty) : 'Included'}</b></div>`
    ).join('') +
    (state.extra.room ? `<div class="sp-cart-item"><span>Extra Room <b>×${state.extra.room}</b></span><b>${euro(state.extra.room*129)}</b></div>`:'') +
    (state.extra.ac ? `<div class="sp-cart-item"><span>Additional Air Conditioner <b>×${state.extra.ac}</b></span><b>${euro(state.extra.ac*99)}</b></div>`:'') +
    (state.setup ? `<div class="sp-cart-item"><span>One-time Setup</span><b>${euro(79)}</b></div>`:'');
    root.querySelectorAll('[data-extra-value]').forEach(el => el.textContent = state.extra[el.dataset.extraValue]);
    root.querySelectorAll('[data-setup]').forEach(el => el.checked = state.setup);
  }

  root.addEventListener('click', e => {
    const b = e.target.closest('[data-extra][data-delta]');
    if (b) {
      const key=b.dataset.extra;
      state.extra[key]=Math.max(0,state.extra[key]+Number(b.dataset.delta));
      render(); return;
    }
    const node=e.target.closest('.sp-node');
    if(node){
      root.querySelectorAll('.sp-node').forEach(n=>n.classList.remove('is-active'));
      node.classList.add('is-active');
      const key=node.dataset.productKey;
      const p=catalog[key];
      if(p && p.price) {
        const detail=`${p.name} · ${euro(p.price)} per stuk`;
        node.title=detail;
      }
    }
  });

  root.addEventListener('change', e => {
    if(e.target.matches('[data-setup]')){
      state.setup=e.target.checked;
      render();
    }
  });

  root.querySelector('[data-add-all]').addEventListener('click', async () => {
    const btn=root.querySelector('[data-add-all]');
    btn.disabled=true; btn.textContent='Toevoegen…';

    // Product IDs are supplied by WordPress through data attributes if configured.
    const nodes=[...root.querySelectorAll('[data-product-key]')];
    const requests=[];
    nodes.forEach(n=>{
      const id=Number(n.dataset.productId || 0);
      const key=n.dataset.productKey;
      if(id>0 && catalog[key]?.qty>0) requests.push({
        path:'/wc/store/v1/cart/add-item',method:'POST',body:{id,quantity:catalog[key].qty}
      });
    });

    const extras=root.querySelector('[data-extra-products]');
    const roomId=Number(extras?.dataset.roomProductId || 0);
    const acId=Number(extras?.dataset.acProductId || 0);
    const setupId=Number(extras?.dataset.setupProductId || 0);

    if(roomId>0 && state.extra.room>0) requests.push({
      path:'/wc/store/v1/cart/add-item',method:'POST',body:{id:roomId,quantity:state.extra.room}
    });
    if(acId>0 && state.extra.ac>0) requests.push({
      path:'/wc/store/v1/cart/add-item',method:'POST',body:{id:acId,quantity:state.extra.ac}
    });
    if(setupId>0 && state.setup) requests.push({
      path:'/wc/store/v1/cart/add-item',method:'POST',body:{id:setupId,quantity:1}
    });

    if(requests.length){
      try{
        const res=await fetch(SOFO_SPITI_CONFIG.storeApi+'/batch',{
          method:'POST',
          headers:{'Content-Type':'application/json','Nonce':SOFO_SPITI_CONFIG.nonce,'X-WC-Store-API-Nonce':SOFO_SPITI_CONFIG.nonce},
          body:JSON.stringify({requests})
        });
        if(!res.ok) throw new Error('WooCommerce cart request failed');
        window.location.href=SOFO_SPITI_CONFIG.cartUrl;
      }catch(err){
        alert('De selectie kon niet aan de winkelwagen worden toegevoegd. Controleer de WooCommerce product-ID configuratie.');
        btn.disabled=false; btn.textContent='🛒 Add selection to cart';
      }
    } else {
      alert('De demo is klaar. Vul in de plugin de echte WooCommerce product-ID’s in om live te kunnen afrekenen.');
      btn.disabled=false; btn.textContent='🛒 Add selection to cart';
    }
  });

  render();
})();
