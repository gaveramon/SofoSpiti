<?php
/**
 * Plugin Name: SOFO SPITI – Smart Property Configurator
 * Description: Interactive "spider-wheel" product configurator for SOFO SPITI + WooCommerce.
 * Version: 1.0.0
 * Author: SOFO SPITI
 */

if ( ! defined( 'ABSPATH' ) ) exit;

final class SOFO_SPITI_Config {
    public function __construct() {
        add_shortcode( 'sofospiti_configurator', [ $this, 'shortcode' ] );
        add_action( 'wp_enqueue_scripts', [ $this, 'assets' ] );
    }

    public function assets() {
        if ( ! is_singular() ) return;
        global $post;
        if ( ! $post || ! has_shortcode( $post->post_content, 'sofospiti_configurator' ) ) return;

        wp_register_style(
            'sofospiti-inter',
            'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap',
            [],
            null
        );
        wp_enqueue_style( 'sofospiti-inter' );

        wp_register_style(
            'sofospiti-configurator',
            plugins_url( 'assets/configurator.css', __FILE__ ),
            [],
            '1.1.0'
        );
        wp_enqueue_style( 'sofospiti-configurator' );

        wp_register_script(
            'sofospiti-configurator',
            plugins_url( 'assets/configurator.js', __FILE__ ),
            [],
            '1.1.0',
            true
        );
        wp_enqueue_script( 'sofospiti-configurator' );

        wp_localize_script( 'sofospiti-configurator', 'SOFO_SPITI_CONFIG', [
            'storeApi' => esc_url_raw( rest_url( 'wc/store/v1' ) ),
            'nonce'    => function_exists( 'wp_create_nonce' ) ? wp_create_nonce( 'wc_store_api' ) : '',
            'currency' => 'EUR',
            'cartUrl'  => function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : '#',
        ] );
    }

    /**
     * Configure the catalog here.
     * Replace product_id values with the real WooCommerce product IDs.
     * Prices are display fallbacks; WooCommerce remains the price authority.
     */
    private function catalog() {
        return [
            'hub' => [
                'name' => 'Aqara M3 Hub',
                'product_id' => 0,
                'price' => 129,
                'qty' => 1,
            ],
            'door' => [
                'name' => 'Door & Window Sensor P100',
                'product_id' => 0,
                'price' => 29,
                'qty' => 2,
                'feature' => 'Door & Window Protection',
                'icon' => '▣',
            ],
            'leak' => [
                'name' => 'Water Leak Sensor',
                'product_id' => 0,
                'price' => 24,
                'qty' => 1,
                'feature' => 'Leak Protection',
                'icon' => '◉',
            ],
            'climate' => [
                'name' => 'Aqara Climate Sensor W100',
                'product_id' => 0,
                'price' => 39,
                'qty' => 1,
                'feature' => 'Climate Control',
                'icon' => '♨',
            ],
            'energy' => [
                'name' => 'Aqara Smart Plug',
                'product_id' => 0,
                'price' => 25,
                'qty' => 2,
                'feature' => 'Energy Monitoring',
                'icon' => 'ϟ',
            ],
            'presence' => [
                'name' => 'Presence Sensor FP300',
                'product_id' => 0,
                'price' => 30,
                'qty' => 1,
                'feature' => 'Presence Detection',
                'icon' => '◌',
            ],
            'alarm' => [
                'name' => 'Smoke / Alarm Sensor',
                'product_id' => 0,
                'price' => 35,
                'qty' => 1,
                'feature' => 'Alarm Control',
                'icon' => '⬡',
            ],
            'ac' => [
                'name' => 'AC Automation',
                'product_id' => 0,
                'price' => 0,
                'qty' => 1,
                'feature' => 'AC Automation',
                'icon' => '▱',
                'included' => true,
            ],
            'alerts' => [
                'name' => 'Notifications & Alerts',
                'product_id' => 0,
                'price' => 0,
                'qty' => 1,
                'feature' => 'Notifications & Alerts',
                'icon' => '▯',
                'included' => true,
            ],
            'room' => [
                'name' => 'Extra Room',
                'product_id' => 0,
                'price' => 129,
                'qty' => 0,
            ],
            'extra_ac' => [
                'name' => 'Additional Air Conditioner',
                'product_id' => 0,
                'price' => 99,
                'qty' => 0,
            ],
            'setup' => [
                'name' => 'One-time Professional Setup',
                'product_id' => 0,
                'price' => 79,
                'qty' => 1,
            ],
        ];
    }

    public function shortcode( $atts = [] ) {
        if ( ! class_exists( 'WooCommerce' ) ) {
            return '<div class="sofospiti-notice">WooCommerce is required for the SOFO SPITI configurator.</div>';
        }

        $c = $this->catalog();

        $features = [
            ['key'=>'door',     'angle'=>-90],
            ['key'=>'climate',  'angle'=>-45],
            ['key'=>'presence', 'angle'=>0],
            ['key'=>'alerts',   'angle'=>45],
            ['key'=>'alarm',    'angle'=>90],
            ['key'=>'ac',       'angle'=>135],
            ['key'=>'energy',   'angle'=>180],
            ['key'=>'leak',     'angle'=>225],
        ];

        ob_start(); ?>
        <section class="sofospiti-configurator" data-configurator>
            <div class="sp-wrap">
                <div class="sp-intro">
                    <div class="sp-eyebrow">SOFO SPITI · SMART PROPERTY</div>
                    <h1>Energy Saving<br><span>&amp; Security</span></h1>
                    <p>Stel je smart-property pakket samen. Kies een functie, voeg apparatuur toe en zie direct hoe jouw woning wordt opgebouwd.</p>
                    <div class="sp-rating"><span>★★★★★</span> <b>4.9/5</b> · property owners</div>
                    <div class="sp-from">Vanaf <strong>€399</strong></div>
                    <div class="sp-benefits">
                        <span>◌ Easy setup</span><span>⌂ Aqara ecosystem</span><span>✣ Uitbreidbaar</span>
                    </div>
                </div>

                <div class="sp-wheel-panel">
                    <div class="sp-wheel" aria-label="Smart property functies">
                        <svg class="sp-lines" viewBox="0 0 600 600" preserveAspectRatio="none" aria-hidden="true">
                            <circle cx="300" cy="300" r="185" class="ring ring-outer"/>
                            <circle cx="300" cy="300" r="108" class="ring ring-inner"/>
                            <?php foreach ($features as $i => $f): ?>
                                <?php
                                $rad = deg2rad($f['angle']);
                                $x = 300 + cos($rad)*185;
                                $y = 300 + sin($rad)*185;
                                ?>
                                <line x1="300" y1="300" x2="<?php echo esc_attr($x); ?>" y2="<?php echo esc_attr($y); ?>" class="sp-line"/>
                                <?php
                                $next = $features[($i+1)%count($features)];
                                $rad2 = deg2rad($next['angle']);
                                $x2 = 300 + cos($rad2)*185;
                                $y2 = 300 + sin($rad2)*185;
                                ?>
                                <line x1="<?php echo esc_attr($x); ?>" y1="<?php echo esc_attr($y); ?>" x2="<?php echo esc_attr($x2); ?>" y2="<?php echo esc_attr($y2); ?>" class="sp-line sp-line-soft"/>
                            <?php endforeach; ?>
                        </svg>

                        <div class="sp-hub">
                            <div class="sp-hub-icon">M3</div>
                            <strong>AQARA M3 HUB</strong>
                            <small>The Brain of<br>Your Property</small>
                        </div>

                        <?php foreach ($features as $f): $p = $c[$f['key']]; ?>
                            <button class="sp-node <?php echo !empty($p['included']) ? 'is-included' : ''; ?>"
                                style="--angle: <?php echo esc_attr($f['angle']); ?>deg"
                                data-feature="<?php echo esc_attr($p['feature'] ?? $p['name']); ?>"
                                data-product-key="<?php echo esc_attr($f['key']); ?>" data-product-id="<?php echo esc_attr($p['product_id']); ?>"
                                type="button">
                                <span class="sp-node-count"><?php echo !empty($p['included']) ? 'Included' : esc_html($p['qty']); ?></span>
                                <span class="sp-node-icon"><?php echo esc_html($p['icon'] ?? '•'); ?></span>
                                <span class="sp-node-label"><?php echo esc_html($p['feature'] ?? $p['name']); ?></span>
                            </button>
                        <?php endforeach; ?>
                    </div>
                    <div class="sp-hint">Klik op een functie om het product aan te passen.</div>
                </div>

                <aside class="sp-cart">
                    <div class="sp-cart-head">
                        <h2>Your Package</h2>
                        <span class="sp-cart-count" data-cart-count>0</span>
                    </div>
                    <div class="sp-cart-items" data-cart-items></div>
                    <div class="sp-cart-section" data-extra-products data-room-product-id="<?php echo esc_attr($c['room']['product_id']); ?>" data-ac-product-id="<?php echo esc_attr($c['extra_ac']['product_id']); ?>" data-setup-product-id="<?php echo esc_attr($c['setup']['product_id']); ?>">
                        <div class="sp-section-title">EXPANSION MODULES</div>
                        <div class="sp-extra-row"><span>Extra Room</span><div class="sp-stepper"><button data-extra="room" data-delta="-1">−</button><b data-extra-value="room">0</b><button data-extra="room" data-delta="1">+</button></div></div>
                        <div class="sp-extra-row"><span>Additional Air Conditioner</span><div class="sp-stepper"><button data-extra="ac" data-delta="-1">−</button><b data-extra-value="ac">0</b><button data-extra="ac" data-delta="1">+</button></div></div>
                    </div>
                    <div class="sp-cart-section">
                        <div class="sp-section-title">SERVICES</div>
                        <label class="sp-setup-row"><span><b>One-time Setup</b><small>Apparatuur voorbereiden, koppelen, automatiseren &amp; testen</small></span><input type="checkbox" data-setup></label>
                    </div>
                    <div class="sp-total">
                        <span>Total</span><strong data-total>€0</strong>
                    </div>
                    <button class="sp-add" type="button" data-add-all>🛒 Add selection to cart</button>
                    <a class="sp-cart-link" href="<?php echo esc_url(wc_get_cart_url()); ?>">Bekijk winkelwagen →</a>
                </aside>
            </div>

            <div class="sp-options">
                <div class="sp-options-head">
                    <div><div class="sp-eyebrow">EXPAND YOUR PROPERTY</div><h2>Extra opties</h2><p>Breid je pakket uit waar je het nodig hebt.</p></div>
                </div>
                <div class="sp-option-grid">
                    <article class="sp-option-card">
                        <div class="sp-option-image">ROOM</div>
                        <div><h3>Extra Room</h3><p>Bescherm een extra slaapkamer, appartement of kantoor.</p><ul><li>2× Door &amp; Window Sensor</li><li>2× Smart Plug</li><li>1× Smoke Detector</li></ul></div>
                        <div class="sp-option-bottom"><strong>€129</strong><span>per extra room</span><div class="sp-stepper"><button data-extra="room" data-delta="-1">−</button><b data-extra-value="room">0</b><button data-extra="room" data-delta="1">+</button></div></div>
                    </article>
                    <article class="sp-option-card purple">
                        <div class="sp-option-image">AC</div>
                        <div><h3>Additional Air Conditioner</h3><p>Extend automation to another AC unit.</p><ul><li>1× Hub M2</li><li>1× Climate Sensor</li></ul></div>
                        <div class="sp-option-bottom"><strong>€99</strong><span>per AC unit</span><div class="sp-stepper"><button data-extra="ac" data-delta="-1">−</button><b data-extra-value="ac">0</b><button data-extra="ac" data-delta="1">+</button></div></div>
                    </article>
                    <article class="sp-option-card setup-card">
                        <div><div class="sp-setup-icon">⚙</div><h3>Eenmalige Setup</h3><p>Wij bereiden de apparatuur voor vóór levering.</p><ul><li>Pairing met M3</li><li>Firmware updates</li><li>Automatiseringen &amp; scenes</li><li>Test &amp; quality check</li><li>Remote assistance</li></ul></div>
                        <div class="sp-option-bottom"><strong>€79</strong><span>eenmalige service</span><label class="sp-check"><input type="checkbox" data-setup><span>Toevoegen</span></label></div>
                    </article>
                </div>
            </div>
        </section>
        <?php
        return ob_get_clean();
    }
}
new SOFO_SPITI_Config();
